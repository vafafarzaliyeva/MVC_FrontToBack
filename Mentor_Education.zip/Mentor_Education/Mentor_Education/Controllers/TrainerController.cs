﻿using Microsoft.AspNetCore.Mvc;

namespace Mentor_Education.Controllers
{
    public class TrainerController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
